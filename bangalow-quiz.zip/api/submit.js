// /api/submit.js
// Vercel serverless function (Node runtime) — no framework required.
// Works whether the quiz is a plain static site on Vercel or sits inside
// a Next.js app under /pages/api or /app/api (see note at bottom for App Router).
//
// Env var required (set in Vercel dashboard -> Project -> Settings -> Environment Variables):
//   WEBHOOK_URL = https://your-ghl-or-zapier-or-n8n-endpoint.com/hook/xxxx
//
// Optional env vars:
//   ALLOWED_ORIGIN = https://your-parent-site.com   (locks down CORS, defaults to *)
//   WEBHOOK_SECRET = some-shared-secret             (sent as a header to the webhook)

export default async function handler(req, res) {
  const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';

  // CORS — needed since the quiz iframe/page and this API may be on different origins
  res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const webhookUrl = process.env.WEBHOOK_URL;
  if (!webhookUrl) {
    console.error('Missing WEBHOOK_URL env var');
    return res.status(500).json({ error: 'Server misconfigured' });
  }

  let body = req.body;
  // Body may arrive as a string depending on runtime/config — normalize it
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  body = body || {};

  // Minimal validation — adjust required fields to match your quiz
  if (!body.email && !body.phone) {
    return res.status(400).json({ error: 'Missing contact details' });
  }

  const payload = {
    ...body,
    submitted_at: new Date().toISOString(),
    source: 'bangalow-dental-quiz',
    ip: req.headers['x-forwarded-for'] || req.socket?.remoteAddress || null,
    user_agent: req.headers['user-agent'] || null,
  };

  try {
    const webhookRes = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(process.env.WEBHOOK_SECRET ? { 'X-Webhook-Secret': process.env.WEBHOOK_SECRET } : {}),
      },
      body: JSON.stringify(payload),
    });

    if (!webhookRes.ok) {
      const text = await webhookRes.text().catch(() => '');
      console.error('Webhook responded with error', webhookRes.status, text);
      return res.status(502).json({ error: 'Webhook rejected the submission' });
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Failed to reach webhook', err);
    return res.status(502).json({ error: 'Failed to reach webhook' });
  }
}

/*
  ============================================================
  If this project is Next.js App Router instead of plain Vercel functions,
  put this at /app/api/submit/route.js and use this shape instead:
  ============================================================

  export async function POST(req) {
    const webhookUrl = process.env.WEBHOOK_URL;
    if (!webhookUrl) {
      return Response.json({ error: 'Server misconfigured' }, { status: 500 });
    }

    const body = await req.json();
    if (!body.email && !body.phone) {
      return Response.json({ error: 'Missing contact details' }, { status: 400 });
    }

    const payload = {
      ...body,
      submitted_at: new Date().toISOString(),
      source: 'bangalow-dental-quiz',
    };

    const webhookRes = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!webhookRes.ok) {
      return Response.json({ error: 'Webhook rejected the submission' }, { status: 502 });
    }

    return Response.json({ ok: true });
  }

  export function OPTIONS() {
    return new Response(null, { status: 204 });
  }
*/
